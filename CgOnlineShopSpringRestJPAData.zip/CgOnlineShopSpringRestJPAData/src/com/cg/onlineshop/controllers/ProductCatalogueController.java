package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShopServices;

@RestController
public class ProductCatalogueController {
	@Autowired
	private OnlineShopServices onlineShopServices;
	private Product product;
	private ArrayList<Product> products;

	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello() {
		ResponseEntity<String> response = new ResponseEntity<String>("Hello From RESTful Services", HttpStatus.OK);
		return response;
	}

	@RequestMapping(value = "/acceptProductDetails", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product) {
		onlineShopServices.acceptProductDetails(product);
		return new ResponseEntity<String>("Product details successfully added", HttpStatus.OK);
	}

	@RequestMapping(value = "/getProductDetails", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetails(@RequestParam("productId") int productId)
			throws ProductDetailsNotFoundException {
		product = onlineShopServices.getProductDetails(productId);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	@RequestMapping(value = "/removeProductDetails", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	// Format that we are delivering to the client
	public ResponseEntity<String> removeProductDetails(@RequestParam("productId") int productId) {
		onlineShopServices.removeProductDetails(productId);
		return new ResponseEntity<String>("Product deleted with Product ID: " + productId, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAllProductDetails", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetails() {
		products = (ArrayList<Product>) onlineShopServices.getAllProductDetails();
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
}
